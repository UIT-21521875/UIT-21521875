<?php
/**
 * Header template
 *
 * @package woostify
 */

do_action( 'woostify_template_part_header' );
